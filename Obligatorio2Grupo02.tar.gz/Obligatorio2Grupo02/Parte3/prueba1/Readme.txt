Debdio al problema en la funcion run_dijkstra tuvimos que capturar las pruebas en pedazos, las que estan etiquetadas como "svhost2"
corresponden a las capturas luego de bajar el vhost2